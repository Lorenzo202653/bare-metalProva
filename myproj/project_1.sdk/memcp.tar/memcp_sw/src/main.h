/*
 * main.h
 *
 *  Created on: Feb 2, 2017
 *      Author: Mattia Bernasconi
 *        Mail: mattia@studiobernasconi.com
 */

#ifndef SRC_MAIN_H_
#define SRC_MAIN_H_

#include <stdio.h>
#include "application.h"

#include "platform.h"
#include "platform_config.h"

#endif /* SRC_MAIN_H_ */



